package com.java.exerciseone;

import java.util.Scanner;

public class SumOfTheCubesOfNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number");
		int number = sc.nextInt();
		sumOfCubes(number);
	}

	public static void sumOfCubes(int num) {
		int sum = 0;
		while (num != 0) {
			int digit = num % 10;
			int cube = (int) Math.pow(digit, 3);
			sum += cube;
			num = num / 10;
		}
		System.out.println(sum);
	}

}
