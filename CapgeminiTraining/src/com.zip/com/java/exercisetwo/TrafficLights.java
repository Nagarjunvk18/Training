package com.java.exercisetwo;

import java.util.Scanner;

public class TrafficLights {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the buttonOne");
		String button = sc.next();

		switch (button) {
		case "red":
			System.out.println("Please Stop!!");
			break;
		case "yellow":
			System.out.println("Please get Ready!!");
			break;
		case "green":
			System.out.println("Please Go!!");
			break;
		default:
			System.out.println("Improper choice");
		}
	}

}
