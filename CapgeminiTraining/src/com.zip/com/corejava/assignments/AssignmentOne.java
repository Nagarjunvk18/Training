package com.corejava.assignments;
import java.util.Scanner;
public class AssignmentOne {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the principal amount");
		double principalAmount = sc.nextDouble();
		System.out.println("Enter the number of years");
		int years = sc.nextInt();
		System.out.println("Enter the rate of interest");
		float rateOfInterest = sc.nextFloat();
		
		double simpleInterest = (principalAmount*years*rateOfInterest)/100;
		System.out.println("Simple Interest = "+simpleInterest);
		System.out.println("Total amount with Interest = "+(principalAmount+simpleInterest));
	}

}
